
document.addEventListener("DOMContentLoaded", function () {
  const multiStepModal = document.getElementById("multi-step-register");
  const openBtn = document.getElementById("open-multistep-btn");
  const closeBtn = multiStepModal.querySelector(".close-button");
  const step1 = multiStepModal.querySelector(".step-1");
  const step2 = multiStepModal.querySelector(".step-2");
  const nextStep = document.getElementById("next-step");
  const form = document.getElementById("step-form");

  openBtn.addEventListener("click", () => {
    multiStepModal.classList.remove("hidden");
    step1.classList.remove("hidden"); step1.classList.add("active");
    step2.classList.add("hidden");
  });
  closeBtn.addEventListener("click", () => multiStepModal.classList.add("hidden"));

  nextStep.addEventListener("click", () => {
    const name = document.getElementById("step-name").value.trim();
    const email = document.getElementById("step-email").value.trim();
    const pass = document.getElementById("step-password").value;
    const conf = document.getElementById("step-confirm-password").value;
    if (!name || !email || !pass || pass !== conf) return alert("Preencha os campos corretamente.");
    step1.classList.add("hidden");
    step2.classList.remove("hidden"); step2.classList.add("active");
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const cpf = document.getElementById("step-cpf").value;
    const phone = document.getElementById("step-phone").value;
    const nat = document.getElementById("step-nationality").value;
    const terms = document.getElementById("step-terms").checked;
    if (!cpf || !phone || !nat || !terms) return alert("Preencha todos os campos da etapa 2.");
    alert("Cadastro realizado com sucesso!");
    multiStepModal.classList.add("hidden");
  });

  const activities = [
    "Carlos venceu R$ 10 no Jogo da Velha!", "Mariana ganhou R$ 25 na Dama!", "João faturou R$ 15 no Puxa-Puxa!", "Ana venceu R$ 8 agora!", "Pedro ganhou R$ 30!"
  ];
  const feed = document.getElementById("activity-feed");
  setInterval(() => {
    const msg = activities[Math.floor(Math.random() * activities.length)];
    feed.textContent = msg;
    feed.classList.remove("hidden");
    setTimeout(() => feed.classList.add("hidden"), 8000);
  }, 20000);
});
